package com.ta.utdid2.core.persistent;

import com.ta.utdid2.core.persistent.MySharedPreferences.MyEditor;
import com.ta.utdid2.core.persistent.MySharedPreferences.OnSharedPreferenceChangeListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParserException;

public class TransactionXMLFile {
    private static final Object GLOBAL_COMMIT_LOCK = new Object();
    public static final int MODE_PRIVATE = 0;
    public static final int MODE_WORLD_READABLE = 1;
    public static final int MODE_WORLD_WRITEABLE = 2;
    private File mPreferencesDir;
    private final Object mSync = new Object();
    private HashMap<File, MySharedPreferencesImpl> sSharedPrefs = new HashMap();

    private static final class MySharedPreferencesImpl implements MySharedPreferences {
        private static final Object mContent = new Object();
        private boolean hasChange = false;
        private final File mBackupFile;
        private final File mFile;
        private WeakHashMap<OnSharedPreferenceChangeListener, Object> mListeners;
        private Map mMap;
        private final int mMode;

        public final class EditorImpl implements MyEditor {
            private boolean mClear = false;
            private final Map<String, Object> mModified = new HashMap();

            public MyEditor putString(String key, String value) {
                synchronized (this) {
                    this.mModified.put(key, value);
                }
                return this;
            }

            public MyEditor putInt(String key, int value) {
                synchronized (this) {
                    this.mModified.put(key, Integer.valueOf(value));
                }
                return this;
            }

            public MyEditor putLong(String key, long value) {
                synchronized (this) {
                    this.mModified.put(key, Long.valueOf(value));
                }
                return this;
            }

            public MyEditor putFloat(String key, float value) {
                synchronized (this) {
                    this.mModified.put(key, Float.valueOf(value));
                }
                return this;
            }

            public MyEditor putBoolean(String key, boolean value) {
                synchronized (this) {
                    this.mModified.put(key, Boolean.valueOf(value));
                }
                return this;
            }

            public MyEditor remove(String key) {
                synchronized (this) {
                    this.mModified.put(key, this);
                }
                return this;
            }

            public MyEditor clear() {
                synchronized (this) {
                    this.mClear = true;
                }
                return this;
            }

            /* JADX WARNING: inconsistent code. */
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public boolean commit() {
                /*
                r15 = this;
                r1 = 1;
                r12 = 0;
                r5 = 0;
                r8 = 0;
                r13 = com.ta.utdid2.core.persistent.TransactionXMLFile.GLOBAL_COMMIT_LOCK;
                monitor-enter(r13);
                r14 = com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.this;	 Catch:{ all -> 0x0094 }
                r14 = r14.mListeners;	 Catch:{ all -> 0x0094 }
                r14 = r14.size();	 Catch:{ all -> 0x0094 }
                if (r14 <= 0) goto L_0x006e;
            L_0x0015:
                if (r1 == 0) goto L_0x002d;
            L_0x0017:
                r6 = new java.util.ArrayList;	 Catch:{ all -> 0x0094 }
                r6.<init>();	 Catch:{ all -> 0x0094 }
                r9 = new java.util.HashSet;	 Catch:{ all -> 0x00c2 }
                r12 = com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.this;	 Catch:{ all -> 0x00c2 }
                r12 = r12.mListeners;	 Catch:{ all -> 0x00c2 }
                r12 = r12.keySet();	 Catch:{ all -> 0x00c2 }
                r9.<init>(r12);	 Catch:{ all -> 0x00c2 }
                r8 = r9;
                r5 = r6;
            L_0x002d:
                monitor-enter(r15);	 Catch:{ all -> 0x0094 }
                r12 = r15.mClear;	 Catch:{ all -> 0x0091 }
                if (r12 == 0) goto L_0x003e;
            L_0x0032:
                r12 = com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.this;	 Catch:{ all -> 0x0091 }
                r12 = r12.mMap;	 Catch:{ all -> 0x0091 }
                r12.clear();	 Catch:{ all -> 0x0091 }
                r12 = 0;
                r15.mClear = r12;	 Catch:{ all -> 0x0091 }
            L_0x003e:
                r12 = r15.mModified;	 Catch:{ all -> 0x0091 }
                r12 = r12.entrySet();	 Catch:{ all -> 0x0091 }
                r12 = r12.iterator();	 Catch:{ all -> 0x0091 }
            L_0x0048:
                r14 = r12.hasNext();	 Catch:{ all -> 0x0091 }
                if (r14 != 0) goto L_0x0070;
            L_0x004e:
                r12 = r15.mModified;	 Catch:{ all -> 0x0091 }
                r12.clear();	 Catch:{ all -> 0x0091 }
                monitor-exit(r15);	 Catch:{ all -> 0x0091 }
                r12 = com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.this;	 Catch:{ all -> 0x0094 }
                r10 = r12.writeFileLocked();	 Catch:{ all -> 0x0094 }
                if (r10 == 0) goto L_0x0062;
            L_0x005c:
                r12 = com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.this;	 Catch:{ all -> 0x0094 }
                r14 = 1;
                r12.setHasChange(r14);	 Catch:{ all -> 0x0094 }
            L_0x0062:
                monitor-exit(r13);	 Catch:{ all -> 0x0094 }
                if (r1 == 0) goto L_0x006d;
            L_0x0065:
                r12 = r5.size();
                r2 = r12 + -1;
            L_0x006b:
                if (r2 >= 0) goto L_0x00a1;
            L_0x006d:
                return r10;
            L_0x006e:
                r1 = r12;
                goto L_0x0015;
            L_0x0070:
                r0 = r12.next();	 Catch:{ all -> 0x0091 }
                r0 = (java.util.Map.Entry) r0;	 Catch:{ all -> 0x0091 }
                r3 = r0.getKey();	 Catch:{ all -> 0x0091 }
                r3 = (java.lang.String) r3;	 Catch:{ all -> 0x0091 }
                r11 = r0.getValue();	 Catch:{ all -> 0x0091 }
                if (r11 != r15) goto L_0x0097;
            L_0x0082:
                r14 = com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.this;	 Catch:{ all -> 0x0091 }
                r14 = r14.mMap;	 Catch:{ all -> 0x0091 }
                r14.remove(r3);	 Catch:{ all -> 0x0091 }
            L_0x008b:
                if (r1 == 0) goto L_0x0048;
            L_0x008d:
                r5.add(r3);	 Catch:{ all -> 0x0091 }
                goto L_0x0048;
            L_0x0091:
                r12 = move-exception;
                monitor-exit(r15);	 Catch:{ all -> 0x0091 }
                throw r12;	 Catch:{ all -> 0x0094 }
            L_0x0094:
                r12 = move-exception;
            L_0x0095:
                monitor-exit(r13);	 Catch:{ all -> 0x0094 }
                throw r12;
            L_0x0097:
                r14 = com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.this;	 Catch:{ all -> 0x0091 }
                r14 = r14.mMap;	 Catch:{ all -> 0x0091 }
                r14.put(r3, r11);	 Catch:{ all -> 0x0091 }
                goto L_0x008b;
            L_0x00a1:
                r4 = r5.get(r2);
                r4 = (java.lang.String) r4;
                r12 = r8.iterator();
            L_0x00ab:
                r13 = r12.hasNext();
                if (r13 != 0) goto L_0x00b4;
            L_0x00b1:
                r2 = r2 + -1;
                goto L_0x006b;
            L_0x00b4:
                r7 = r12.next();
                r7 = (com.ta.utdid2.core.persistent.MySharedPreferences.OnSharedPreferenceChangeListener) r7;
                if (r7 == 0) goto L_0x00ab;
            L_0x00bc:
                r13 = com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.this;
                r7.onSharedPreferenceChanged(r13, r4);
                goto L_0x00ab;
            L_0x00c2:
                r12 = move-exception;
                r5 = r6;
                goto L_0x0095;
                */
                throw new UnsupportedOperationException("Method not decompiled: com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl.EditorImpl.commit():boolean");
            }
        }

        MySharedPreferencesImpl(File file, int mode, Map initialContents) {
            this.mFile = file;
            this.mBackupFile = TransactionXMLFile.makeBackupFile(file);
            this.mMode = mode;
            if (initialContents == null) {
                initialContents = new HashMap();
            }
            this.mMap = initialContents;
            this.mListeners = new WeakHashMap();
        }

        public boolean checkFile() {
            if (this.mFile == null || !new File(this.mFile.getAbsolutePath()).exists()) {
                return false;
            }
            return true;
        }

        public void setHasChange(boolean hasChange) {
            synchronized (this) {
                this.hasChange = hasChange;
            }
        }

        public boolean hasFileChanged() {
            boolean z;
            synchronized (this) {
                z = this.hasChange;
            }
            return z;
        }

        public void replace(Map newContents) {
            if (newContents != null) {
                synchronized (this) {
                    this.mMap = newContents;
                }
            }
        }

        public void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener listener) {
            synchronized (this) {
                this.mListeners.put(listener, mContent);
            }
        }

        public void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener listener) {
            synchronized (this) {
                this.mListeners.remove(listener);
            }
        }

        public Map<String, ?> getAll() {
            Map hashMap;
            synchronized (this) {
                hashMap = new HashMap(this.mMap);
            }
            return hashMap;
        }

        public String getString(String key, String defValue) {
            String v;
            synchronized (this) {
                v = (String) this.mMap.get(key);
                if (v == null) {
                    v = defValue;
                }
            }
            return v;
        }

        public int getInt(String key, int defValue) {
            synchronized (this) {
                Integer v = (Integer) this.mMap.get(key);
                if (v != null) {
                    defValue = v.intValue();
                }
            }
            return defValue;
        }

        public long getLong(String key, long defValue) {
            synchronized (this) {
                Long v = (Long) this.mMap.get(key);
                if (v != null) {
                    defValue = v.longValue();
                }
            }
            return defValue;
        }

        public float getFloat(String key, float defValue) {
            synchronized (this) {
                Float v = (Float) this.mMap.get(key);
                if (v != null) {
                    defValue = v.floatValue();
                }
            }
            return defValue;
        }

        public boolean getBoolean(String key, boolean defValue) {
            synchronized (this) {
                Boolean v = (Boolean) this.mMap.get(key);
                if (v != null) {
                    defValue = v.booleanValue();
                }
            }
            return defValue;
        }

        public boolean contains(String key) {
            boolean containsKey;
            synchronized (this) {
                containsKey = this.mMap.containsKey(key);
            }
            return containsKey;
        }

        public MyEditor edit() {
            return new EditorImpl();
        }

        private FileOutputStream createFileOutputStream(File file) {
            FileOutputStream str = null;
            try {
                str = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                if (!file.getParentFile().mkdir()) {
                    return null;
                }
                try {
                    str = new FileOutputStream(file);
                } catch (FileNotFoundException e2) {
                }
            }
            return str;
        }

        private boolean writeFileLocked() {
            if (this.mFile.exists()) {
                if (this.mBackupFile.exists()) {
                    this.mFile.delete();
                } else if (!this.mFile.renameTo(this.mBackupFile)) {
                    return false;
                }
            }
            try {
                FileOutputStream str = createFileOutputStream(this.mFile);
                if (str == null) {
                    return false;
                }
                XmlUtils.writeMapXml(this.mMap, str);
                str.close();
                this.mBackupFile.delete();
                return true;
            } catch (XmlPullParserException e) {
                if (this.mFile.exists()) {
                    return false;
                }
                this.mFile.delete();
                return false;
            } catch (IOException e2) {
                if (this.mFile.exists()) {
                    return false;
                }
                this.mFile.delete();
                return false;
            }
        }
    }

    public TransactionXMLFile(String dir) {
        if (dir == null || dir.length() <= 0) {
            throw new RuntimeException("Directory can not be empty");
        }
        this.mPreferencesDir = new File(dir);
    }

    private File makeFilename(File base, String name) {
        if (name.indexOf(File.separatorChar) < 0) {
            return new File(base, name);
        }
        throw new IllegalArgumentException("File " + name + " contains a path separator");
    }

    private File getPreferencesDir() {
        File file;
        synchronized (this.mSync) {
            file = this.mPreferencesDir;
        }
        return file;
    }

    private File getSharedPrefsFile(String name) {
        return makeFilename(getPreferencesDir(), new StringBuilder(String.valueOf(name)).append(".xml").toString());
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.ta.utdid2.core.persistent.MySharedPreferences getMySharedPreferences(java.lang.String r17, int r18) {
        /*
        r16 = this;
        r6 = r16.getSharedPrefsFile(r17);
        r13 = GLOBAL_COMMIT_LOCK;
        monitor-enter(r13);
        r0 = r16;
        r12 = r0.sSharedPrefs;	 Catch:{ all -> 0x005c }
        r8 = r12.get(r6);	 Catch:{ all -> 0x005c }
        r8 = (com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl) r8;	 Catch:{ all -> 0x005c }
        if (r8 == 0) goto L_0x001c;
    L_0x0013:
        r12 = r8.hasFileChanged();	 Catch:{ all -> 0x005c }
        if (r12 != 0) goto L_0x001c;
    L_0x0019:
        monitor-exit(r13);	 Catch:{ all -> 0x005c }
        r9 = r8;
    L_0x001b:
        return r9;
    L_0x001c:
        monitor-exit(r13);	 Catch:{ all -> 0x005c }
        r10 = 0;
        r1 = makeBackupFile(r6);
        r12 = r1.exists();
        if (r12 == 0) goto L_0x002e;
    L_0x0028:
        r6.delete();
        r1.renameTo(r6);
    L_0x002e:
        r12 = r6.exists();
        if (r12 == 0) goto L_0x0037;
    L_0x0034:
        r6.canRead();
    L_0x0037:
        r7 = 0;
        r12 = r6.exists();
        if (r12 == 0) goto L_0x0051;
    L_0x003e:
        r12 = r6.canRead();
        if (r12 == 0) goto L_0x0051;
    L_0x0044:
        r11 = new java.io.FileInputStream;	 Catch:{ XmlPullParserException -> 0x005f, FileNotFoundException -> 0x0084, IOException -> 0x0089, Exception -> 0x008e }
        r11.<init>(r6);	 Catch:{ XmlPullParserException -> 0x005f, FileNotFoundException -> 0x0084, IOException -> 0x0089, Exception -> 0x008e }
        r7 = com.ta.utdid2.core.persistent.XmlUtils.readMapXml(r11);	 Catch:{ XmlPullParserException -> 0x00c5, FileNotFoundException -> 0x00bd, IOException -> 0x00ba, Exception -> 0x00b7 }
        r11.close();	 Catch:{ XmlPullParserException -> 0x00c5, FileNotFoundException -> 0x00bd, IOException -> 0x00ba, Exception -> 0x00b7 }
        r10 = r11;
    L_0x0051:
        r13 = GLOBAL_COMMIT_LOCK;
        monitor-enter(r13);
        if (r8 == 0) goto L_0x0093;
    L_0x0056:
        r8.replace(r7);	 Catch:{ all -> 0x00b1 }
    L_0x0059:
        monitor-exit(r13);	 Catch:{ all -> 0x00b1 }
        r9 = r8;
        goto L_0x001b;
    L_0x005c:
        r12 = move-exception;
        monitor-exit(r13);	 Catch:{ all -> 0x005c }
        throw r12;
    L_0x005f:
        r3 = move-exception;
        r11 = r10;
    L_0x0061:
        r10 = new java.io.FileInputStream;	 Catch:{ FileNotFoundException -> 0x00c2, IOException -> 0x007e }
        r10.<init>(r6);	 Catch:{ FileNotFoundException -> 0x00c2, IOException -> 0x007e }
        r12 = r10.available();	 Catch:{ FileNotFoundException -> 0x0079, IOException -> 0x00c0 }
        r2 = new byte[r12];	 Catch:{ FileNotFoundException -> 0x0079, IOException -> 0x00c0 }
        r10.read(r2);	 Catch:{ FileNotFoundException -> 0x0079, IOException -> 0x00c0 }
        r12 = new java.lang.String;	 Catch:{ FileNotFoundException -> 0x0079, IOException -> 0x00c0 }
        r13 = 0;
        r14 = r2.length;	 Catch:{ FileNotFoundException -> 0x0079, IOException -> 0x00c0 }
        r15 = "UTF-8";
        r12.<init>(r2, r13, r14, r15);	 Catch:{ FileNotFoundException -> 0x0079, IOException -> 0x00c0 }
        goto L_0x0051;
    L_0x0079:
        r4 = move-exception;
    L_0x007a:
        r4.printStackTrace();
        goto L_0x0051;
    L_0x007e:
        r5 = move-exception;
        r10 = r11;
    L_0x0080:
        r5.printStackTrace();
        goto L_0x0051;
    L_0x0084:
        r3 = move-exception;
    L_0x0085:
        r3.printStackTrace();
        goto L_0x0051;
    L_0x0089:
        r3 = move-exception;
    L_0x008a:
        r3.printStackTrace();
        goto L_0x0051;
    L_0x008e:
        r3 = move-exception;
    L_0x008f:
        r3.printStackTrace();
        goto L_0x0051;
    L_0x0093:
        r0 = r16;
        r12 = r0.sSharedPrefs;	 Catch:{ all -> 0x00b1 }
        r12 = r12.get(r6);	 Catch:{ all -> 0x00b1 }
        r0 = r12;
        r0 = (com.ta.utdid2.core.persistent.TransactionXMLFile.MySharedPreferencesImpl) r0;	 Catch:{ all -> 0x00b1 }
        r8 = r0;
        if (r8 != 0) goto L_0x0059;
    L_0x00a1:
        r9 = new com.ta.utdid2.core.persistent.TransactionXMLFile$MySharedPreferencesImpl;	 Catch:{ all -> 0x00b1 }
        r0 = r18;
        r9.<init>(r6, r0, r7);	 Catch:{ all -> 0x00b1 }
        r0 = r16;
        r12 = r0.sSharedPrefs;	 Catch:{ all -> 0x00b4 }
        r12.put(r6, r9);	 Catch:{ all -> 0x00b4 }
        r8 = r9;
        goto L_0x0059;
    L_0x00b1:
        r12 = move-exception;
    L_0x00b2:
        monitor-exit(r13);	 Catch:{ all -> 0x00b1 }
        throw r12;
    L_0x00b4:
        r12 = move-exception;
        r8 = r9;
        goto L_0x00b2;
    L_0x00b7:
        r3 = move-exception;
        r10 = r11;
        goto L_0x008f;
    L_0x00ba:
        r3 = move-exception;
        r10 = r11;
        goto L_0x008a;
    L_0x00bd:
        r3 = move-exception;
        r10 = r11;
        goto L_0x0085;
    L_0x00c0:
        r5 = move-exception;
        goto L_0x0080;
    L_0x00c2:
        r4 = move-exception;
        r10 = r11;
        goto L_0x007a;
    L_0x00c5:
        r3 = move-exception;
        goto L_0x0061;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.ta.utdid2.core.persistent.TransactionXMLFile.getMySharedPreferences(java.lang.String, int):com.ta.utdid2.core.persistent.MySharedPreferences");
    }

    private static File makeBackupFile(File prefsFile) {
        return new File(prefsFile.getPath() + ".bak");
    }
}
