package com.tencent.wxop.stat.a;

import com.ut.device.AidConstants;

public enum f {
    PAGE_VIEW(1),
    SESSION_ENV(2),
    ERROR(3),
    CUSTOM(AidConstants.EVENT_REQUEST_STARTED),
    ADDITION(AidConstants.EVENT_REQUEST_SUCCESS),
    MONITOR_STAT(AidConstants.EVENT_REQUEST_FAILED),
    MTA_GAME_USER(AidConstants.EVENT_NETWORK_ERROR),
    NETWORK_MONITOR(1004),
    NETWORK_DETECTOR(1005);
    
    private int j;

    private f(int i) {
        this.j = i;
    }

    public final int a() {
        return this.j;
    }
}
