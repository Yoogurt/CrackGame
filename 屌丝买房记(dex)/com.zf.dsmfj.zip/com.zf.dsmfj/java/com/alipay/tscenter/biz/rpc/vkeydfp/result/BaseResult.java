package com.alipay.tscenter.biz.rpc.vkeydfp.result;

import java.io.Serializable;

public class BaseResult implements Serializable {
    public String resultCode;
    public boolean success = false;
}
