package com.alipay.tscenter.biz.rpc.vkeydfp.request;

import java.io.Serializable;

public class AppListCmdRequest implements Serializable {
    public String apdid;
    public String applist;
    public String os;
    public String token;
    public String userId;
}
