package com.alipay.tscenter.biz.rpc.vkeydfp.result;

import java.io.Serializable;

public class AppListResult extends BaseResult implements Serializable {
    public String appListData;
    public String appListVer;
}
