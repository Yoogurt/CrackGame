package com.alipay.sdk.authjs;

public interface b {
    void a(a aVar);
}
