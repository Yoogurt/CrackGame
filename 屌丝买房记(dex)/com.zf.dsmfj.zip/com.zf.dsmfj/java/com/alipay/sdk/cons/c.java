package com.alipay.sdk.cons;

public final class c {
    public static final String a = "status";
    public static final String b = "msg";
    public static final String c = "form";
    public static final String d = "onload";
    public static final String e = "name";
    public static final String f = "host";
    public static final String g = "params";
    public static final String h = "enctype";
    public static final String i = "request_param";
    public static final String j = "validate";
    public static final String k = "formSubmit";
    public static final String l = "namespace";
    public static final String m = "apiVersion";
    public static final String n = "apiName";
}
