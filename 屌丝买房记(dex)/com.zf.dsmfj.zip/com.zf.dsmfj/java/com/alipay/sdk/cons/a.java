package com.alipay.sdk.cons;

public final class a {
    public static String a = "http://mobilegw.alipay.com/mgw.htm";
    public static final String b = "https://mobilegw.alipaydev.com/mgw.htm";
    public static String c = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDENksAVqDoz5SMCZq0bsZwE+I3NjrANyTTwUVSf1+ec1PfPB4tiocEpYJFCYju9MIbawR8ivECbUWjpffZq5QllJg+19CB7V5rYGcEnb/M7CS3lFF2sNcRFJUtXUUAqyR3/l7PmpxTwObZ4DLG258dhE2vFlVGXjnuLs+FI2hg4QIDAQAB";
    public static final String d = "2014052600006128";
    public static final String e = "1";
    public static final String f = "15.2.7";
    public static final String g = "h.a.3.2.7";
    public static final String h = "b6cbad6cbd5ed0d209afc69ad3b7a617efaae9b3c47eabe0be42d924936fa78c8001b1fd74b079e5ff9690061dacfa4768e981a526b9ca77156ca36251cf2f906d105481374998a7e6e6e18f75ca98b8ed2eaf86ff402c874cca0a263053f22237858206867d210020daa38c48b20cc9dfd82b44a51aeb5db459b22794e2d649";
    public static final String i = "alipays://platformapi/startApp?";
    public static final String j = "intent://platformapi/startapp?";
    public static final String k = "sdklite://h5quit?result=";
    public static final String l = "sdklite://h5quit";
    public static final String m = "http://m.alipay.com/?action=h5quit";
    public static final String n = "&end_code=";
    public static final String o = "&return_url=\"";
    public static final String p = "&return_url=";
}
