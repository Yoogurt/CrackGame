package com.alipay.sdk.cons;

public final class b {
    public static final String a = "https";
    public static final String b = "user_agent";
    public static final String c = "tid";
    public static final String d = "external_info";
    public static final String e = "has_alipay";
    public static final String f = "has_msp_app";
    public static final String g = "utdid";
    public static final String h = "app_key";
    public static final String i = "trideskey";
    public static final String j = "new_client_key";
}
