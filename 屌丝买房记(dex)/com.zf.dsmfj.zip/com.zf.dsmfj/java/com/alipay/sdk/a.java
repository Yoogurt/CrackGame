package com.alipay.sdk;

public final class a {
    public static final boolean a = false;
}
