package com.alipay.sdk.packet.impl;

import org.json.JSONException;
import org.json.JSONObject;

public final class d extends com.alipay.sdk.packet.d {
    protected final JSONObject a() throws JSONException {
        return com.alipay.sdk.packet.d.a("cashier", "main");
    }
}
