package com.alipay.sdk.packet;

public final class c {
    boolean a;
    byte[] b;

    public c(boolean z, byte[] bArr) {
        this.a = z;
        this.b = bArr;
    }

    private boolean a() {
        return this.a;
    }

    private void a(boolean z) {
        this.a = z;
    }

    private byte[] b() {
        return this.b;
    }

    private void a(byte[] bArr) {
        this.b = bArr;
    }
}
