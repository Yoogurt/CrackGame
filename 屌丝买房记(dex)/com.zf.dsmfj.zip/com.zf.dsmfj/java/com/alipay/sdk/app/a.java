package com.alipay.sdk.app;

final class a implements com.alipay.sdk.util.e.a {
    final /* synthetic */ AuthTask a;

    a(AuthTask authTask) {
        this.a = authTask;
    }

    public final void a() {
        this.a.c();
    }
}
