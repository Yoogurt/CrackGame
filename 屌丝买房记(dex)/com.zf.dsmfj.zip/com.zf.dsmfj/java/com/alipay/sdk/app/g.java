package com.alipay.sdk.app;

import com.alipay.sdk.util.e.a;

final class g implements a {
    final /* synthetic */ PayTask a;

    g(PayTask payTask) {
        this.a = payTask;
    }

    public final void a() {
        this.a.c();
    }
}
