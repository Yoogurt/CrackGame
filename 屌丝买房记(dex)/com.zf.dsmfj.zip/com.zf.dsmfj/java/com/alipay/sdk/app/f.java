package com.alipay.sdk.app;

final class f implements Runnable {
    final /* synthetic */ b a;

    f(b bVar) {
        this.a = bVar;
    }

    public final void run() {
        this.a.b();
    }
}
