package com.alipay.sdk.app;

import com.alipay.android.phone.mrpc.core.RpcException.ErrorCode;

public enum i {
    SUCCEEDED(9000, "\u5904\u7406\u6210\u529f"),
    FAILED(4000, "\u7cfb\u7edf\u7e41\u5fd9\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5"),
    CANCELED(ErrorCode.SERVER_METHODNOTFOUND, "\u7528\u6237\u53d6\u6d88"),
    NETWORK_ERROR(ErrorCode.SERVER_PARAMMISSING, "\u7f51\u7edc\u8fde\u63a5\u5f02\u5e38"),
    PARAMS_ERROR(ErrorCode.SERVER_REQUESTTIMEOUT, "\u53c2\u6570\u9519\u8bef"),
    DOUBLE_REQUEST(ErrorCode.SERVER_UNKNOWERROR, "\u91cd\u590d\u8bf7\u6c42"),
    PAY_WAITTING(8000, "\u652f\u4ed8\u7ed3\u679c\u786e\u8ba4\u4e2d");
    
    public int h;
    public String i;

    private i(int i, String str) {
        this.h = i;
        this.i = str;
    }

    private void b(int i) {
        this.h = i;
    }

    private int a() {
        return this.h;
    }

    private void a(String str) {
        this.i = str;
    }

    private String b() {
        return this.i;
    }

    public static i a(int i) {
        switch (i) {
            case ErrorCode.SERVER_REQUESTTIMEOUT /*4001*/:
                return PARAMS_ERROR;
            case ErrorCode.SERVER_UNKNOWERROR /*5000*/:
                return DOUBLE_REQUEST;
            case ErrorCode.SERVER_METHODNOTFOUND /*6001*/:
                return CANCELED;
            case ErrorCode.SERVER_PARAMMISSING /*6002*/:
                return NETWORK_ERROR;
            case 8000:
                return PAY_WAITTING;
            case 9000:
                return SUCCEEDED;
            default:
                return FAILED;
        }
    }
}
