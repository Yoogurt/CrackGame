package com.alipay.sdk.auth;

import android.app.Activity;

public class AlipaySDK {
    public static void auth(Activity activity, APAuthInfo aPAuthInfo) {
        h.a(activity, aPAuthInfo);
    }
}
