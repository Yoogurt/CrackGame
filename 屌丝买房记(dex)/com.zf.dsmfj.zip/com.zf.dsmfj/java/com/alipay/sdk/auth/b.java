package com.alipay.sdk.auth;

import com.alipay.sdk.authjs.a;

final class b implements com.alipay.sdk.authjs.b {
    final /* synthetic */ AuthActivity a;

    b(AuthActivity authActivity) {
        this.a = authActivity;
    }

    public final void a(a aVar) {
        AuthActivity.a(this.a, aVar);
    }
}
