package com.alipay.android.phone.mrpc.core;

public interface RpcCaller {
    Object call();
}
