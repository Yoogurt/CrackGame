package com.alipay.android.phone.mrpc.core;

import com.zf.dsmfj.Constant;
import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;

public class HttpCaller extends AbstractRpcCaller {
    private static final String CONTENT_TYPE = "application/x-www-form-urlencoded";
    private Config mConfig;

    public HttpCaller(Config config, Method method, int i, String str, byte[] bArr, boolean z) {
        super(method, i, str, bArr, CONTENT_TYPE, z);
        this.mConfig = config;
    }

    private void addHeader(HttpUrlRequest httpUrlRequest) {
        httpUrlRequest.addHeader(new BasicHeader("uuid", UUID.randomUUID().toString()));
        List<Header> headers = this.mConfig.getRpcParams().getHeaders();
        if (headers != null && !headers.isEmpty()) {
            for (Header addHeader : headers) {
                httpUrlRequest.addHeader(addHeader);
            }
        }
    }

    private Transport getTransport() {
        return this.mConfig.getTransport();
    }

    private int transferCode(int i) {
        switch (i) {
            case Constant.DIALOG_NEWGAME /*1*/:
                return 2;
            case Constant.DIALOG_BUYGOODS /*2*/:
                return 3;
            case Constant.DIALOG_SELLGOODS /*3*/:
                return 4;
            case Constant.DIALOG_ENDGAME /*4*/:
                return 5;
            case Constant.DIALOG_BANK /*5*/:
                return 6;
            case Constant.DIALOG_BANK_SAVE /*6*/:
                return 7;
            case Constant.DIALOG_BANK_GET /*7*/:
                return 8;
            case Constant.DIALOG_HOSPITAL_ASK /*8*/:
                return 15;
            case Constant.DIALOG_HOSPITAL_FULL /*9*/:
                return 16;
            default:
                return i;
        }
    }

    public Object call() {
        Throwable e;
        Request httpUrlRequest = new HttpUrlRequest(this.mConfig.getUrl());
        httpUrlRequest.setReqData(this.mReqData);
        httpUrlRequest.setContentType(this.mContentType);
        httpUrlRequest.setResetCookie(this.mResetCookie);
        httpUrlRequest.addTags("id", String.valueOf(this.mId));
        httpUrlRequest.addTags("operationType", this.mOperationType);
        httpUrlRequest.addTags("gzip", String.valueOf(this.mConfig.isGzip()));
        addHeader(httpUrlRequest);
        new StringBuilder("threadid = ").append(Thread.currentThread().getId()).append("; ").append(httpUrlRequest.toString());
        try {
            Response response = (Response) getTransport().execute(httpUrlRequest).get();
            if (response != null) {
                return response.getResData();
            }
            throw new RpcException(Integer.valueOf(9), "response is null");
        } catch (Throwable e2) {
            throw new RpcException(Integer.valueOf(13), "", e2);
        } catch (Throwable e22) {
            Throwable th = e22;
            e22 = th.getCause();
            if (e22 == null || !(e22 instanceof HttpException)) {
                throw new RpcException(Integer.valueOf(9), "", th);
            }
            HttpException httpException = (HttpException) e22;
            throw new RpcException(Integer.valueOf(transferCode(httpException.getCode())), httpException.getMsg());
        } catch (Throwable e222) {
            throw new RpcException(Integer.valueOf(13), "", e222);
        }
    }
}
