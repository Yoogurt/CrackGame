package com.alipay.android.phone.mrpc.core;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import com.zf.dsmfj.Constant;
import org.apache.http.HttpHost;

public class NetworkUtils {
    public static final int NETWORK_TYPE_2G = 1;
    public static final int NETWORK_TYPE_3G_4G = 2;
    public static final int NETWORK_TYPE_INVALID = 0;
    public static final int NETWORK_TYPE_LTE = 13;
    public static final int NETWORK_TYPE_WIFI = 3;

    public static NetworkInfo getActiveNetworkInfo(Context context) {
        return ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
    }

    public static int getNetType(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo == null ? -1 : activeNetworkInfo.getType();
    }

    public static int getNetworkType(Context context) {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo != null) {
            if (!activeNetworkInfo.isConnected()) {
                return NETWORK_TYPE_INVALID;
            }
            int type = activeNetworkInfo.getType();
            if (type == NETWORK_TYPE_2G) {
                return NETWORK_TYPE_WIFI;
            }
            if (type == 0) {
                return is3GMobileNetwork(activeNetworkInfo) ? NETWORK_TYPE_3G_4G : NETWORK_TYPE_2G;
            }
        }
        return NETWORK_TYPE_INVALID;
    }

    public static HttpHost getProxy(Context context) {
        NetworkInfo activeNetworkInfo = getActiveNetworkInfo(context);
        if (activeNetworkInfo == null || !activeNetworkInfo.isAvailable()) {
            return null;
        }
        String defaultHost = Proxy.getDefaultHost();
        return defaultHost != null ? new HttpHost(defaultHost, Proxy.getDefaultPort()) : null;
    }

    private static boolean is3GMobileNetwork(NetworkInfo networkInfo) {
        if (networkInfo == null) {
            return false;
        }
        switch (networkInfo.getSubtype()) {
            case NETWORK_TYPE_INVALID /*0*/:
            case NETWORK_TYPE_2G /*1*/:
            case NETWORK_TYPE_3G_4G /*2*/:
            case Constant.DIALOG_ENDGAME /*4*/:
            case Constant.DIALOG_BANK_GET /*7*/:
            case Constant.DIALOG_AGENT /*11*/:
                return false;
            case NETWORK_TYPE_WIFI /*3*/:
                return true;
            case Constant.DIALOG_BANK /*5*/:
                return true;
            case Constant.DIALOG_BANK_SAVE /*6*/:
                return true;
            case Constant.DIALOG_HOSPITAL_ASK /*8*/:
                return true;
            case Constant.DIALOG_HOSPITAL_FULL /*9*/:
                return true;
            case Constant.DIALOG_HOSPITAL_NOMONEY /*10*/:
                return true;
            case NETWORK_TYPE_LTE /*13*/:
                return true;
            default:
                return false;
        }
    }

    public static boolean isNetworkAvailable(Context context) {
        NetworkInfo[] allNetworkInfo = ((ConnectivityManager) context.getSystemService("connectivity")).getAllNetworkInfo();
        if (allNetworkInfo == null) {
            return false;
        }
        boolean z;
        int length = allNetworkInfo.length;
        for (int i = NETWORK_TYPE_INVALID; i < length; i += NETWORK_TYPE_2G) {
            NetworkInfo networkInfo = allNetworkInfo[i];
            if (networkInfo != null && networkInfo.isAvailable() && networkInfo.isConnectedOrConnecting()) {
                z = true;
                break;
            }
        }
        z = false;
        return z;
    }
}
