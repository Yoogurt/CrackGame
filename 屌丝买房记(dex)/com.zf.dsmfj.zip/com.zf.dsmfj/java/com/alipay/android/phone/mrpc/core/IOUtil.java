package com.alipay.android.phone.mrpc.core;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

public class IOUtil {
    public static byte[] InputStreamToByte(InputStream inputStream) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        while (true) {
            int read = inputStream.read();
            if (read != -1) {
                byteArrayOutputStream.write(read);
            } else {
                byte[] toByteArray = byteArrayOutputStream.toByteArray();
                byteArrayOutputStream.close();
                return toByteArray;
            }
        }
    }

    public static void closeStream(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String convertStreamToString(java.io.InputStream r3) {
        /*
        r0 = new java.io.BufferedReader;
        r1 = new java.io.InputStreamReader;
        r1.<init>(r3);
        r0.<init>(r1);
        r1 = new java.lang.StringBuilder;
        r1.<init>();
    L_0x000f:
        r2 = r0.readLine();	 Catch:{ IOException -> 0x0019, all -> 0x0028 }
        if (r2 == 0) goto L_0x0022;
    L_0x0015:
        r1.append(r2);	 Catch:{ IOException -> 0x0019, all -> 0x0028 }
        goto L_0x000f;
    L_0x0019:
        r0 = move-exception;
        r3.close();	 Catch:{ IOException -> 0x002d }
    L_0x001d:
        r0 = r1.toString();
        return r0;
    L_0x0022:
        r3.close();	 Catch:{ IOException -> 0x0026 }
        goto L_0x001d;
    L_0x0026:
        r0 = move-exception;
        goto L_0x001d;
    L_0x0028:
        r0 = move-exception;
        r3.close();	 Catch:{ IOException -> 0x002f }
    L_0x002c:
        throw r0;
    L_0x002d:
        r0 = move-exception;
        goto L_0x001d;
    L_0x002f:
        r1 = move-exception;
        goto L_0x002c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.alipay.android.phone.mrpc.core.IOUtil.convertStreamToString(java.io.InputStream):java.lang.String");
    }

    public static byte[] fileToByte(File file) {
        RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
        try {
            long length = randomAccessFile.length();
            int i = (int) length;
            if (((long) i) != length) {
                throw new IOException("File size >= 2 GB");
            }
            byte[] bArr = new byte[i];
            randomAccessFile.readFully(bArr);
            return bArr;
        } finally {
            randomAccessFile.close();
        }
    }
}
