package com.alipay.android.phone.mrpc.core.gwprotocol;

public interface Deserializer {
    Object parser();
}
