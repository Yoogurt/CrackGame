package com.alipay.android.phone.mrpc.core;

import android.content.Context;
import android.text.TextUtils;
import android.webkit.CookieManager;
import com.alipay.sdk.util.h;
import com.qq.e.comm.constants.ErrorCode.InitError;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.Callable;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.AbstractHttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

public class HttpWorker implements Callable<Response> {
    private static final String TAG = "HttpWorker";
    private static final HttpRequestRetryHandler sHttpRequestRetryHandler = new ZHttpRequestRetryHandler();
    private String etagCacheKey = null;
    private boolean hasEtagInResponse = false;
    private boolean hasIfNoneMatchInRequest = false;
    protected Context mContext;
    private CookieManager mCookieManager;
    private CookieStore mCookieStore = new BasicCookieStore();
    private HttpHost mHttpHost;
    protected HttpManager mHttpManager;
    private HttpUriRequest mHttpRequest;
    private HttpContext mLocalContext = new BasicHttpContext();
    private String mOperationType;
    private AbstractHttpEntity mPostDataEntity;
    protected HttpUrlRequest mRequest;
    private int mRetryTimes = 0;
    private URL mTargetUrl;
    String mUrl;

    public HttpWorker(HttpManager httpManager, HttpUrlRequest httpUrlRequest) {
        this.mHttpManager = httpManager;
        this.mContext = this.mHttpManager.mContext;
        this.mRequest = httpUrlRequest;
    }

    private void abortRequest() {
        if (this.mHttpRequest != null) {
            this.mHttpRequest.abort();
        }
    }

    private void addRequestHeaders() {
        ArrayList headers = getHeaders();
        if (!(headers == null || headers.isEmpty())) {
            Iterator it = headers.iterator();
            while (it.hasNext()) {
                getHttpUriRequest().addHeader((Header) it.next());
            }
        }
        AndroidHttpClient.modifyRequestToAcceptGzipResponse(getHttpUriRequest());
        AndroidHttpClient.modifyRequestToKeepAlive(getHttpUriRequest());
        getHttpUriRequest().addHeader("cookie", getCookieManager().getCookie(this.mRequest.getUrl()));
    }

    private HttpResponse executeHttpClientRequest() {
        new StringBuilder("By Http/Https to request. operationType=").append(getOperationType()).append(" url=").append(this.mHttpRequest.getURI().toString());
        getHttpClient().getParams().setParameter("http.route.default-proxy", getProxy());
        HttpHost httpHost = getHttpHost();
        if (getTargetPort() == 80) {
            httpHost = new HttpHost(getTargetURL().getHost());
        }
        return getHttpClient().execute(httpHost, this.mHttpRequest, this.mLocalContext);
    }

    private HttpResponse executeRequest() {
        return executeHttpClientRequest();
    }

    private CookieManager getCookieManager() {
        if (this.mCookieManager != null) {
            return this.mCookieManager;
        }
        this.mCookieManager = CookieManager.getInstance();
        return this.mCookieManager;
    }

    private AndroidHttpClient getHttpClient() {
        return this.mHttpManager.getHttpClient();
    }

    private HttpHost getHttpHost() {
        if (this.mHttpHost != null) {
            return this.mHttpHost;
        }
        URL targetURL = getTargetURL();
        this.mHttpHost = new HttpHost(targetURL.getHost(), getTargetPort(), targetURL.getProtocol());
        return this.mHttpHost;
    }

    private HttpUriRequest getHttpUriRequest() {
        if (this.mHttpRequest != null) {
            return this.mHttpRequest;
        }
        HttpEntity postData = getPostData();
        if (postData != null) {
            HttpUriRequest httpPost = new HttpPost(getUri());
            httpPost.setEntity(postData);
            this.mHttpRequest = httpPost;
        } else {
            this.mHttpRequest = new HttpGet(getUri());
        }
        return this.mHttpRequest;
    }

    private String getOperationType() {
        if (!TextUtils.isEmpty(this.mOperationType)) {
            return this.mOperationType;
        }
        this.mOperationType = this.mRequest.getTag("operationType");
        return this.mOperationType;
    }

    private HttpHost getProxy() {
        HttpHost proxy = NetworkUtils.getProxy(this.mContext);
        return (proxy != null && TextUtils.equals(proxy.getHostName(), "127.0.0.1") && proxy.getPort() == 8087) ? null : proxy;
    }

    private int getTargetPort() {
        URL targetURL = getTargetURL();
        return targetURL.getPort() == -1 ? targetURL.getDefaultPort() : targetURL.getPort();
    }

    private URL getTargetURL() {
        if (this.mTargetUrl != null) {
            return this.mTargetUrl;
        }
        this.mTargetUrl = new URL(this.mRequest.getUrl());
        return this.mTargetUrl;
    }

    private TransportCallback getTransportCallback() {
        return this.mRequest.getCallback();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public com.alipay.android.phone.mrpc.core.Response call() {
        /*
        r13 = this;
        r12 = 4;
        r11 = 0;
        r10 = 6;
        r9 = 3;
        r8 = 2;
        r2 = r13.mContext;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = com.alipay.android.phone.mrpc.core.NetworkUtils.isNetworkAvailable(r2);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r2 != 0) goto L_0x003e;
    L_0x000d:
        r2 = new com.alipay.android.phone.mrpc.core.HttpException;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r3 = 1;
        r3 = java.lang.Integer.valueOf(r3);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r4 = "The network is not available";
        r2.<init>(r3, r4);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        throw r2;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
    L_0x001a:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x0035;
    L_0x0024:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = r2.getCode();
        r6 = r2.getMsg();
        r3.onFailed(r4, r5, r6);
    L_0x0035:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        throw r2;
    L_0x003e:
        r2 = r13.getTransportCallback();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r2 == 0) goto L_0x004d;
    L_0x0044:
        r2 = r13.getTransportCallback();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r3 = r13.mRequest;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2.onPreExecute(r3);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
    L_0x004d:
        r13.addRequestHeaders();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r13.mLocalContext;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r3 = "http.cookie-store";
        r4 = r13.mCookieStore;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2.setAttribute(r3, r4);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r13.getHttpClient();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r3 = sHttpRequestRetryHandler;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2.setHttpRequestRetryHandler(r3);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = java.lang.System.currentTimeMillis();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r4 = r13.executeRequest();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r6 = java.lang.System.currentTimeMillis();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r5 = r13.mHttpManager;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r6 - r2;
        r5.addConnectTime(r2);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r13.mCookieStore;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r2.getCookies();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r3 = r13.mRequest;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r3 = r3.isResetCookie();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r3 == 0) goto L_0x008a;
    L_0x0083:
        r3 = r13.getCookieManager();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r3.removeAllCookie();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
    L_0x008a:
        r3 = r2.isEmpty();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r3 != 0) goto L_0x0104;
    L_0x0090:
        r3 = r2.iterator();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
    L_0x0094:
        r2 = r3.hasNext();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r2 == 0) goto L_0x0104;
    L_0x009a:
        r2 = r3.next();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = (org.apache.http.cookie.Cookie) r2;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r5 = r2.getDomain();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r5 == 0) goto L_0x0094;
    L_0x00a6:
        r5 = new java.lang.StringBuilder;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r5.<init>();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r6 = r2.getName();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r5 = r5.append(r6);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r6 = "=";
        r5 = r5.append(r6);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r6 = r2.getValue();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r5 = r5.append(r6);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r6 = "; domain=";
        r5 = r5.append(r6);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r6 = r2.getDomain();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r5 = r5.append(r6);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r2.isSecure();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r2 == 0) goto L_0x0101;
    L_0x00d5:
        r2 = "; Secure";
    L_0x00d7:
        r2 = r5.append(r2);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r2.toString();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r5 = r13.getCookieManager();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r6 = r13.mRequest;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r6 = r6.getUrl();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r5.setCookie(r6, r2);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = android.webkit.CookieSyncManager.getInstance();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2.sync();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        goto L_0x0094;
    L_0x00f4:
        r2 = move-exception;
        r3 = new java.lang.RuntimeException;
        r4 = "Url parser error!";
        r2 = r2.getCause();
        r3.<init>(r4, r2);
        throw r3;
    L_0x0101:
        r2 = "";
        goto L_0x00d7;
    L_0x0104:
        r2 = r13.mRequest;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r3 = r13.processResponse(r4, r2);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r4 = -1;
        if (r3 == 0) goto L_0x011a;
    L_0x010e:
        r2 = r3.getResData();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r2 == 0) goto L_0x011a;
    L_0x0114:
        r2 = r3.getResData();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r2.length;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r4 = (long) r2;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
    L_0x011a:
        r6 = -1;
        r2 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1));
        if (r2 != 0) goto L_0x0135;
    L_0x0120:
        r2 = r3 instanceof com.alipay.android.phone.mrpc.core.HttpUrlResponse;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r2 == 0) goto L_0x0135;
    L_0x0124:
        r0 = r3;
        r0 = (com.alipay.android.phone.mrpc.core.HttpUrlResponse) r0;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r0;
        r2 = r2.getHeader();	 Catch:{ Exception -> 0x0371, HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322 }
        r4 = "Content-Length";
        r2 = r2.getHead(r4);	 Catch:{ Exception -> 0x0371, HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322 }
        java.lang.Long.parseLong(r2);	 Catch:{ Exception -> 0x0371, HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322 }
    L_0x0135:
        r2 = r13.mRequest;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r2.getUrl();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r2 == 0) goto L_0x015d;
    L_0x013d:
        r4 = r13.getOperationType();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r4 = android.text.TextUtils.isEmpty(r4);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        if (r4 != 0) goto L_0x015d;
    L_0x0147:
        r4 = new java.lang.StringBuilder;	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r4.<init>();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2 = r4.append(r2);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r4 = "#";
        r2 = r2.append(r4);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r4 = r13.getOperationType();	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
        r2.append(r4);	 Catch:{ HttpException -> 0x001a, URISyntaxException -> 0x00f4, SSLHandshakeException -> 0x015e, SSLPeerUnverifiedException -> 0x018b, SSLException -> 0x01b8, ConnectionPoolTimeoutException -> 0x01e5, ConnectTimeoutException -> 0x0212, SocketTimeoutException -> 0x023f, NoHttpResponseException -> 0x026c, HttpHostConnectException -> 0x029b, UnknownHostException -> 0x02c4, IOException -> 0x02f5, NullPointerException -> 0x0322, Exception -> 0x034c }
    L_0x015d:
        return r3;
    L_0x015e:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x0175;
    L_0x0168:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r8, r5);
    L_0x0175:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r8);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x018b:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x01a2;
    L_0x0195:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r8, r5);
    L_0x01a2:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r8);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x01b8:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x01cf;
    L_0x01c2:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r10, r5);
    L_0x01cf:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r10);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x01e5:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x01fc;
    L_0x01ef:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r9, r5);
    L_0x01fc:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r9);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x0212:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x0229;
    L_0x021c:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r9, r5);
    L_0x0229:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r9);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x023f:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x0256;
    L_0x0249:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r12, r5);
    L_0x0256:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r12);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x026c:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x0284;
    L_0x0276:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = 5;
        r6 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r5, r6);
    L_0x0284:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = 5;
        r4 = java.lang.Integer.valueOf(r4);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x029b:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x02b4;
    L_0x02a5:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = 8;
        r6 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r5, r6);
    L_0x02b4:
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = 8;
        r4 = java.lang.Integer.valueOf(r4);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x02c4:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x02dd;
    L_0x02ce:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = 9;
        r6 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r5, r6);
    L_0x02dd:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = 9;
        r4 = java.lang.Integer.valueOf(r4);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x02f5:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x030c;
    L_0x02ff:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r10, r5);
    L_0x030c:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r10);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x0322:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.mRetryTimes;
        if (r3 > 0) goto L_0x0336;
    L_0x032a:
        r2 = r13.mRetryTimes;
        r2 = r2 + 1;
        r13.mRetryTimes = r2;
        r3 = r13.call();
        goto L_0x015d;
    L_0x0336:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r3.append(r2);
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r11);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x034c:
        r2 = move-exception;
        r13.abortRequest();
        r3 = r13.getTransportCallback();
        if (r3 == 0) goto L_0x0363;
    L_0x0356:
        r3 = r13.getTransportCallback();
        r4 = r13.mRequest;
        r5 = java.lang.String.valueOf(r2);
        r3.onFailed(r4, r11, r5);
    L_0x0363:
        r3 = new com.alipay.android.phone.mrpc.core.HttpException;
        r4 = java.lang.Integer.valueOf(r11);
        r2 = java.lang.String.valueOf(r2);
        r3.<init>(r4, r2);
        throw r3;
    L_0x0371:
        r2 = move-exception;
        goto L_0x0135;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.alipay.android.phone.mrpc.core.HttpWorker.call():com.alipay.android.phone.mrpc.core.Response");
    }

    protected void fillResponse(HttpUrlResponse httpUrlResponse, HttpResponse httpResponse) {
        String str;
        String str2 = null;
        long period = getPeriod(httpResponse);
        Header contentType = httpResponse.getEntity().getContentType();
        if (contentType != null) {
            HashMap contentType2 = getContentType(contentType.getValue());
            str = (String) contentType2.get("charset");
            str2 = (String) contentType2.get("Content-Type");
        } else {
            str = null;
        }
        httpUrlResponse.setContentType(str2);
        httpUrlResponse.setCharset(str);
        httpUrlResponse.setCreateTime(System.currentTimeMillis());
        httpUrlResponse.setPeriod(period);
    }

    protected HashMap<String, String> getContentType(String str) {
        HashMap<String, String> hashMap = new HashMap();
        for (String str2 : str.split(h.b)) {
            String[] split = str2.indexOf(61) == -1 ? new String[]{"Content-Type", str2} : str2.split("=");
            hashMap.put(split[0], split[1]);
        }
        return hashMap;
    }

    protected ArrayList<Header> getHeaders() {
        return this.mRequest.getHeaders();
    }

    protected long getPeriod(HttpResponse httpResponse) {
        long j = 0;
        Header firstHeader = httpResponse.getFirstHeader("Cache-Control");
        if (firstHeader != null) {
            String[] split = firstHeader.getValue().split("=");
            if (split.length >= 2) {
                try {
                    return parserMaxage(split);
                } catch (NumberFormatException e) {
                }
            }
        }
        firstHeader = httpResponse.getFirstHeader("Expires");
        return firstHeader != null ? AndroidHttpClient.parseDate(firstHeader.getValue()) - System.currentTimeMillis() : j;
    }

    protected AbstractHttpEntity getPostData() {
        if (this.mPostDataEntity != null) {
            return this.mPostDataEntity;
        }
        byte[] reqData = this.mRequest.getReqData();
        CharSequence tag = this.mRequest.getTag("gzip");
        if (reqData != null) {
            if (TextUtils.equals(tag, "true")) {
                this.mPostDataEntity = AndroidHttpClient.getCompressedEntity(reqData, null);
            } else {
                this.mPostDataEntity = new ByteArrayEntity(reqData);
            }
            this.mPostDataEntity.setContentType(this.mRequest.getContentType());
        }
        return this.mPostDataEntity;
    }

    public HttpUrlRequest getRequest() {
        return this.mRequest;
    }

    protected URI getUri() {
        String url = this.mRequest.getUrl();
        if (this.mUrl != null) {
            url = this.mUrl;
        }
        if (url != null) {
            return new URI(url);
        }
        throw new RuntimeException("url should not be null");
    }

    protected Response handleResponse(HttpResponse httpResponse, int i, String str) {
        ByteArrayOutputStream byteArrayOutputStream;
        Throwable th;
        Response response = null;
        new StringBuilder("\u5f00\u59cbhandle\uff0chandleResponse-1,").append(Thread.currentThread().getId());
        HttpEntity entity = httpResponse.getEntity();
        if (entity != null && httpResponse.getStatusLine().getStatusCode() == 200) {
            new StringBuilder("200\uff0c\u5f00\u59cb\u5904\u7406\uff0chandleResponse-2,threadid = ").append(Thread.currentThread().getId());
            try {
                byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    long currentTimeMillis = System.currentTimeMillis();
                    writeData(entity, 0, byteArrayOutputStream);
                    byte[] toByteArray = byteArrayOutputStream.toByteArray();
                    this.hasEtagInResponse = false;
                    this.mHttpManager.addSocketTime(System.currentTimeMillis() - currentTimeMillis);
                    this.mHttpManager.addDataSize((long) toByteArray.length);
                    new StringBuilder("res:").append(toByteArray.length);
                    response = new HttpUrlResponse(handleResponseHeader(httpResponse), i, str, toByteArray);
                    fillResponse(response, httpResponse);
                    try {
                        byteArrayOutputStream.close();
                    } catch (IOException e) {
                        throw new RuntimeException("ArrayOutputStream close error!", e.getCause());
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (byteArrayOutputStream != null) {
                        try {
                            byteArrayOutputStream.close();
                        } catch (IOException e2) {
                            throw new RuntimeException("ArrayOutputStream close error!", e2.getCause());
                        }
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                Throwable th4 = th3;
                byteArrayOutputStream = null;
                th = th4;
                if (byteArrayOutputStream != null) {
                    byteArrayOutputStream.close();
                }
                throw th;
            }
        } else if (entity == null) {
            httpResponse.getStatusLine().getStatusCode();
        }
        return response;
    }

    protected HttpUrlHeader handleResponseHeader(HttpResponse httpResponse) {
        HttpUrlHeader httpUrlHeader = new HttpUrlHeader();
        for (Header header : httpResponse.getAllHeaders()) {
            httpUrlHeader.setHead(header.getName(), header.getValue());
        }
        return httpUrlHeader;
    }

    protected long parserMaxage(String[] strArr) {
        int i = 0;
        while (i < strArr.length) {
            if ("max-age".equalsIgnoreCase(strArr[i]) && strArr[i + 1] != null) {
                try {
                    return Long.parseLong(strArr[i + 1]);
                } catch (Exception e) {
                }
            }
            i++;
        }
        return 0;
    }

    public Response processResponse(HttpResponse httpResponse, HttpUrlRequest httpUrlRequest) {
        int statusCode = httpResponse.getStatusLine().getStatusCode();
        String reasonPhrase = httpResponse.getStatusLine().getReasonPhrase();
        if (statusCode == 200 || willHandleOtherCode(statusCode, reasonPhrase)) {
            return handleResponse(httpResponse, statusCode, reasonPhrase);
        }
        throw new HttpException(Integer.valueOf(httpResponse.getStatusLine().getStatusCode()), httpResponse.getStatusLine().getReasonPhrase());
    }

    protected boolean willHandleOtherCode(int i, String str) {
        return i == InitError.INVALID_REQUEST_ERROR;
    }

    protected void writeData(HttpEntity httpEntity, long j, OutputStream outputStream) {
        if (outputStream == null) {
            httpEntity.consumeContent();
            throw new IllegalArgumentException("Output stream may not be null");
        }
        Closeable ungzippedContent = AndroidHttpClient.getUngzippedContent(httpEntity);
        long contentLength = httpEntity.getContentLength();
        try {
            byte[] bArr = new byte[2048];
            while (true) {
                int read = ungzippedContent.read(bArr);
                if (read == -1 || this.mRequest.isCanceled()) {
                    break;
                }
                outputStream.write(bArr, 0, read);
                j += (long) read;
                if (getTransportCallback() != null && contentLength > 0) {
                    getTransportCallback().onProgressUpdate(this.mRequest, ((double) j) / ((double) contentLength));
                }
            }
            outputStream.flush();
            IOUtil.closeStream(ungzippedContent);
        } catch (Exception e) {
            e.getCause();
            throw new IOException("HttpWorker Request Error!" + e.getLocalizedMessage());
        } catch (Throwable th) {
            IOUtil.closeStream(ungzippedContent);
        }
    }
}
