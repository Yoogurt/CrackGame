package com.alipay.android.phone.mrpc.core;

import java.util.ArrayList;
import org.apache.http.HeaderElement;
import org.apache.http.message.BasicHeaderValueParser;
import org.apache.http.message.ParserCursor;
import org.apache.http.util.CharArrayBuffer;

public final class Headers {
    public static final String ACCEPT_RANGES = "accept-ranges";
    public static final String CACHE_CONTROL = "cache-control";
    public static final int CONN_CLOSE = 1;
    public static final String CONN_DIRECTIVE = "connection";
    public static final int CONN_KEEP_ALIVE = 2;
    public static final String CONTENT_DISPOSITION = "content-disposition";
    public static final String CONTENT_ENCODING = "content-encoding";
    public static final String CONTENT_LEN = "content-length";
    public static final String CONTENT_TYPE = "content-type";
    public static final String ETAG = "etag";
    public static final String EXPIRES = "expires";
    private static final int HASH_ACCEPT_RANGES = 1397189435;
    private static final int HASH_CACHE_CONTROL = -208775662;
    private static final int HASH_CONN_DIRECTIVE = -775651618;
    private static final int HASH_CONTENT_DISPOSITION = -1267267485;
    private static final int HASH_CONTENT_ENCODING = 2095084583;
    private static final int HASH_CONTENT_LEN = -1132779846;
    private static final int HASH_CONTENT_TYPE = 785670158;
    private static final int HASH_ETAG = 3123477;
    private static final int HASH_EXPIRES = -1309235404;
    private static final int HASH_LAST_MODIFIED = 150043680;
    private static final int HASH_LOCATION = 1901043637;
    private static final int HASH_PRAGMA = -980228804;
    private static final int HASH_PROXY_AUTHENTICATE = -301767724;
    private static final int HASH_PROXY_CONNECTION = 285929373;
    private static final int HASH_REFRESH = 1085444827;
    private static final int HASH_SET_COOKIE = 1237214767;
    private static final int HASH_TRANSFER_ENCODING = 1274458357;
    private static final int HASH_WWW_AUTHENTICATE = -243037365;
    private static final int HASH_X_PERMITTED_CROSS_DOMAIN_POLICIES = -1345594014;
    private static final int HEADER_COUNT = 19;
    private static final int IDX_ACCEPT_RANGES = 10;
    private static final int IDX_CACHE_CONTROL = 12;
    private static final int IDX_CONN_DIRECTIVE = 4;
    private static final int IDX_CONTENT_DISPOSITION = 9;
    private static final int IDX_CONTENT_ENCODING = 3;
    private static final int IDX_CONTENT_LEN = 1;
    private static final int IDX_CONTENT_TYPE = 2;
    private static final int IDX_ETAG = 14;
    private static final int IDX_EXPIRES = 11;
    private static final int IDX_LAST_MODIFIED = 13;
    private static final int IDX_LOCATION = 5;
    private static final int IDX_PRAGMA = 16;
    private static final int IDX_PROXY_AUTHENTICATE = 8;
    private static final int IDX_PROXY_CONNECTION = 6;
    private static final int IDX_REFRESH = 17;
    private static final int IDX_SET_COOKIE = 15;
    private static final int IDX_TRANSFER_ENCODING = 0;
    private static final int IDX_WWW_AUTHENTICATE = 7;
    private static final int IDX_X_PERMITTED_CROSS_DOMAIN_POLICIES = 18;
    public static final String LAST_MODIFIED = "last-modified";
    public static final String LOCATION = "location";
    public static final int NO_CONN_TYPE = 0;
    public static final long NO_CONTENT_LENGTH = -1;
    public static final long NO_TRANSFER_ENCODING = 0;
    public static final String PRAGMA = "pragma";
    public static final String PROXY_AUTHENTICATE = "proxy-authenticate";
    public static final String PROXY_CONNECTION = "proxy-connection";
    public static final String REFRESH = "refresh";
    public static final String SET_COOKIE = "set-cookie";
    public static final String TRANSFER_ENCODING = "transfer-encoding";
    public static final String WWW_AUTHENTICATE = "www-authenticate";
    public static final String X_PERMITTED_CROSS_DOMAIN_POLICIES = "x-permitted-cross-domain-policies";
    private static final String[] sHeaderNames;
    private int connectionType = NO_CONN_TYPE;
    private long contentLength = NO_CONTENT_LENGTH;
    private ArrayList<String> cookies = new ArrayList(IDX_CONTENT_TYPE);
    private ArrayList<String> mExtraHeaderNames = new ArrayList(IDX_CONN_DIRECTIVE);
    private ArrayList<String> mExtraHeaderValues = new ArrayList(IDX_CONN_DIRECTIVE);
    private String[] mHeaders = new String[HEADER_COUNT];
    private long transferEncoding = NO_TRANSFER_ENCODING;

    public interface HeaderCallback {
        void header(String str, String str2);
    }

    static {
        String[] strArr = new String[HEADER_COUNT];
        strArr[NO_CONN_TYPE] = TRANSFER_ENCODING;
        strArr[IDX_CONTENT_LEN] = CONTENT_LEN;
        strArr[IDX_CONTENT_TYPE] = CONTENT_TYPE;
        strArr[IDX_CONTENT_ENCODING] = CONTENT_ENCODING;
        strArr[IDX_CONN_DIRECTIVE] = CONN_DIRECTIVE;
        strArr[IDX_LOCATION] = LOCATION;
        strArr[IDX_PROXY_CONNECTION] = PROXY_CONNECTION;
        strArr[IDX_WWW_AUTHENTICATE] = WWW_AUTHENTICATE;
        strArr[IDX_PROXY_AUTHENTICATE] = PROXY_AUTHENTICATE;
        strArr[IDX_CONTENT_DISPOSITION] = CONTENT_DISPOSITION;
        strArr[IDX_ACCEPT_RANGES] = ACCEPT_RANGES;
        strArr[IDX_EXPIRES] = EXPIRES;
        strArr[IDX_CACHE_CONTROL] = CACHE_CONTROL;
        strArr[IDX_LAST_MODIFIED] = LAST_MODIFIED;
        strArr[IDX_ETAG] = ETAG;
        strArr[IDX_SET_COOKIE] = SET_COOKIE;
        strArr[IDX_PRAGMA] = PRAGMA;
        strArr[IDX_REFRESH] = REFRESH;
        strArr[IDX_X_PERMITTED_CROSS_DOMAIN_POLICIES] = X_PERMITTED_CROSS_DOMAIN_POLICIES;
        sHeaderNames = strArr;
    }

    private void setConnectionType(CharArrayBuffer charArrayBuffer, int i) {
        if (CharArrayBuffers.containsIgnoreCaseTrimmed(charArrayBuffer, i, "Close")) {
            this.connectionType = IDX_CONTENT_LEN;
        } else if (CharArrayBuffers.containsIgnoreCaseTrimmed(charArrayBuffer, i, "Keep-Alive")) {
            this.connectionType = IDX_CONTENT_TYPE;
        }
    }

    public final String getAcceptRanges() {
        return this.mHeaders[IDX_ACCEPT_RANGES];
    }

    public final String getCacheControl() {
        return this.mHeaders[IDX_CACHE_CONTROL];
    }

    public final int getConnectionType() {
        return this.connectionType;
    }

    public final String getContentDisposition() {
        return this.mHeaders[IDX_CONTENT_DISPOSITION];
    }

    public final String getContentEncoding() {
        return this.mHeaders[IDX_CONTENT_ENCODING];
    }

    public final long getContentLength() {
        return this.contentLength;
    }

    public final String getContentType() {
        return this.mHeaders[IDX_CONTENT_TYPE];
    }

    public final String getEtag() {
        return this.mHeaders[IDX_ETAG];
    }

    public final String getExpires() {
        return this.mHeaders[IDX_EXPIRES];
    }

    public final void getHeaders(HeaderCallback headerCallback) {
        for (int i = NO_CONN_TYPE; i < HEADER_COUNT; i += IDX_CONTENT_LEN) {
            String str = this.mHeaders[i];
            if (str != null) {
                headerCallback.header(sHeaderNames[i], str);
            }
        }
        int size = this.mExtraHeaderNames.size();
        for (int i2 = NO_CONN_TYPE; i2 < size; i2 += IDX_CONTENT_LEN) {
            headerCallback.header((String) this.mExtraHeaderNames.get(i2), (String) this.mExtraHeaderValues.get(i2));
        }
    }

    public final String getLastModified() {
        return this.mHeaders[IDX_LAST_MODIFIED];
    }

    public final String getLocation() {
        return this.mHeaders[IDX_LOCATION];
    }

    public final String getPragma() {
        return this.mHeaders[IDX_PRAGMA];
    }

    public final String getProxyAuthenticate() {
        return this.mHeaders[IDX_PROXY_AUTHENTICATE];
    }

    public final String getRefresh() {
        return this.mHeaders[IDX_REFRESH];
    }

    public final ArrayList<String> getSetCookie() {
        return this.cookies;
    }

    public final long getTransferEncoding() {
        return this.transferEncoding;
    }

    public final String getWwwAuthenticate() {
        return this.mHeaders[IDX_WWW_AUTHENTICATE];
    }

    public final String getXPermittedCrossDomainPolicies() {
        return this.mHeaders[IDX_X_PERMITTED_CROSS_DOMAIN_POLICIES];
    }

    public final void parseHeader(CharArrayBuffer charArrayBuffer) {
        int lowercaseIndexOf = CharArrayBuffers.setLowercaseIndexOf(charArrayBuffer, 58);
        if (lowercaseIndexOf != -1) {
            String substringTrimmed = charArrayBuffer.substringTrimmed(NO_CONN_TYPE, lowercaseIndexOf);
            if (substringTrimmed.length() != 0) {
                lowercaseIndexOf += IDX_CONTENT_LEN;
                String substringTrimmed2 = charArrayBuffer.substringTrimmed(lowercaseIndexOf, charArrayBuffer.length());
                switch (substringTrimmed.hashCode()) {
                    case HASH_X_PERMITTED_CROSS_DOMAIN_POLICIES /*-1345594014*/:
                        if (substringTrimmed.equals(X_PERMITTED_CROSS_DOMAIN_POLICIES)) {
                            this.mHeaders[IDX_X_PERMITTED_CROSS_DOMAIN_POLICIES] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_EXPIRES /*-1309235404*/:
                        if (substringTrimmed.equals(EXPIRES)) {
                            this.mHeaders[IDX_EXPIRES] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_CONTENT_DISPOSITION /*-1267267485*/:
                        if (substringTrimmed.equals(CONTENT_DISPOSITION)) {
                            this.mHeaders[IDX_CONTENT_DISPOSITION] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_CONTENT_LEN /*-1132779846*/:
                        if (substringTrimmed.equals(CONTENT_LEN)) {
                            this.mHeaders[IDX_CONTENT_LEN] = substringTrimmed2;
                            try {
                                this.contentLength = Long.parseLong(substringTrimmed2);
                                return;
                            } catch (NumberFormatException e) {
                                return;
                            }
                        }
                        return;
                    case HASH_PRAGMA /*-980228804*/:
                        if (substringTrimmed.equals(PRAGMA)) {
                            this.mHeaders[IDX_PRAGMA] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_CONN_DIRECTIVE /*-775651618*/:
                        if (substringTrimmed.equals(CONN_DIRECTIVE)) {
                            this.mHeaders[IDX_CONN_DIRECTIVE] = substringTrimmed2;
                            setConnectionType(charArrayBuffer, lowercaseIndexOf);
                            return;
                        }
                        return;
                    case HASH_PROXY_AUTHENTICATE /*-301767724*/:
                        if (substringTrimmed.equals(PROXY_AUTHENTICATE)) {
                            this.mHeaders[IDX_PROXY_AUTHENTICATE] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_WWW_AUTHENTICATE /*-243037365*/:
                        if (substringTrimmed.equals(WWW_AUTHENTICATE)) {
                            this.mHeaders[IDX_WWW_AUTHENTICATE] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_CACHE_CONTROL /*-208775662*/:
                        if (!substringTrimmed.equals(CACHE_CONTROL)) {
                            return;
                        }
                        if (this.mHeaders[IDX_CACHE_CONTROL] == null || this.mHeaders[IDX_CACHE_CONTROL].length() <= 0) {
                            this.mHeaders[IDX_CACHE_CONTROL] = substringTrimmed2;
                            return;
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        String[] strArr = this.mHeaders;
                        strArr[IDX_CACHE_CONTROL] = stringBuilder.append(strArr[IDX_CACHE_CONTROL]).append(',').append(substringTrimmed2).toString();
                        return;
                    case HASH_ETAG /*3123477*/:
                        if (substringTrimmed.equals(ETAG)) {
                            this.mHeaders[IDX_ETAG] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_LAST_MODIFIED /*150043680*/:
                        if (substringTrimmed.equals(LAST_MODIFIED)) {
                            this.mHeaders[IDX_LAST_MODIFIED] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_PROXY_CONNECTION /*285929373*/:
                        if (substringTrimmed.equals(PROXY_CONNECTION)) {
                            this.mHeaders[IDX_PROXY_CONNECTION] = substringTrimmed2;
                            setConnectionType(charArrayBuffer, lowercaseIndexOf);
                            return;
                        }
                        return;
                    case HASH_CONTENT_TYPE /*785670158*/:
                        if (substringTrimmed.equals(CONTENT_TYPE)) {
                            this.mHeaders[IDX_CONTENT_TYPE] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_REFRESH /*1085444827*/:
                        if (substringTrimmed.equals(REFRESH)) {
                            this.mHeaders[IDX_REFRESH] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_SET_COOKIE /*1237214767*/:
                        if (substringTrimmed.equals(SET_COOKIE)) {
                            this.mHeaders[IDX_SET_COOKIE] = substringTrimmed2;
                            this.cookies.add(substringTrimmed2);
                            return;
                        }
                        return;
                    case HASH_TRANSFER_ENCODING /*1274458357*/:
                        if (substringTrimmed.equals(TRANSFER_ENCODING)) {
                            this.mHeaders[NO_CONN_TYPE] = substringTrimmed2;
                            HeaderElement[] parseElements = BasicHeaderValueParser.DEFAULT.parseElements(charArrayBuffer, new ParserCursor(lowercaseIndexOf, charArrayBuffer.length()));
                            int length = parseElements.length;
                            if ("identity".equalsIgnoreCase(substringTrimmed2) || length <= 0 || !"chunked".equalsIgnoreCase(parseElements[length - 1].getName())) {
                                this.transferEncoding = NO_CONTENT_LENGTH;
                                return;
                            } else {
                                this.transferEncoding = -2;
                                return;
                            }
                        }
                        return;
                    case HASH_ACCEPT_RANGES /*1397189435*/:
                        if (substringTrimmed.equals(ACCEPT_RANGES)) {
                            this.mHeaders[IDX_ACCEPT_RANGES] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_LOCATION /*1901043637*/:
                        if (substringTrimmed.equals(LOCATION)) {
                            this.mHeaders[IDX_LOCATION] = substringTrimmed2;
                            return;
                        }
                        return;
                    case HASH_CONTENT_ENCODING /*2095084583*/:
                        if (substringTrimmed.equals(CONTENT_ENCODING)) {
                            this.mHeaders[IDX_CONTENT_ENCODING] = substringTrimmed2;
                            return;
                        }
                        return;
                    default:
                        this.mExtraHeaderNames.add(substringTrimmed);
                        this.mExtraHeaderValues.add(substringTrimmed2);
                        return;
                }
            }
        }
    }

    public final void setAcceptRanges(String str) {
        this.mHeaders[IDX_ACCEPT_RANGES] = str;
    }

    public final void setCacheControl(String str) {
        this.mHeaders[IDX_CACHE_CONTROL] = str;
    }

    public final void setContentDisposition(String str) {
        this.mHeaders[IDX_CONTENT_DISPOSITION] = str;
    }

    public final void setContentEncoding(String str) {
        this.mHeaders[IDX_CONTENT_ENCODING] = str;
    }

    public final void setContentLength(long j) {
        this.contentLength = j;
    }

    public final void setContentType(String str) {
        this.mHeaders[IDX_CONTENT_TYPE] = str;
    }

    public final void setEtag(String str) {
        this.mHeaders[IDX_ETAG] = str;
    }

    public final void setExpires(String str) {
        this.mHeaders[IDX_EXPIRES] = str;
    }

    public final void setLastModified(String str) {
        this.mHeaders[IDX_LAST_MODIFIED] = str;
    }

    public final void setLocation(String str) {
        this.mHeaders[IDX_LOCATION] = str;
    }

    public final void setProxyAuthenticate(String str) {
        this.mHeaders[IDX_PROXY_AUTHENTICATE] = str;
    }

    public final void setWwwAuthenticate(String str) {
        this.mHeaders[IDX_WWW_AUTHENTICATE] = str;
    }

    public final void setXPermittedCrossDomainPolicies(String str) {
        this.mHeaders[IDX_X_PERMITTED_CROSS_DOMAIN_POLICIES] = str;
    }
}
