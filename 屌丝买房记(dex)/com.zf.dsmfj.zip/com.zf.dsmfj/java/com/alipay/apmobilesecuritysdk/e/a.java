package com.alipay.apmobilesecuritysdk.e;

public final class a {
    private static volatile String a = "";
    private static volatile boolean b = false;

    public static String a() {
        return a;
    }

    public static String b() {
        return a;
    }
}
