package com.alipay.apmobilesecuritysdk.f;

public final class b {
    private String a = "";
    private String b = "";
    private String c = "";

    public b(String str, String str2, String str3) {
        this.a = str;
        this.b = str2;
        this.c = str3;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final String c() {
        return this.c;
    }
}
