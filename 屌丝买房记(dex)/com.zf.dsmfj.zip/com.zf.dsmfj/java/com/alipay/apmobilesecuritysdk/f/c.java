package com.alipay.apmobilesecuritysdk.f;

public final class c {
    private String a = "";
    private String b = "";
    private String c = "";
    private String d = "";
    private String e = "";

    public c(String str, String str2, String str3, String str4, String str5) {
        this.a = str;
        this.b = str2;
        this.c = str3;
        this.d = str4;
        this.e = str5;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final String c() {
        return this.c;
    }

    public final String d() {
        return this.d;
    }

    public final String e() {
        return this.e;
    }
}
