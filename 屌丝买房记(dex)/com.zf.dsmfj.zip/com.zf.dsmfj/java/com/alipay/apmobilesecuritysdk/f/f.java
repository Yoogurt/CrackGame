package com.alipay.apmobilesecuritysdk.f;

import com.alipay.b.a.a.a.a;

public final class f {
    private String a = "";
    private String b = "";
    private String c = "";
    private String d = "";
    private String e = "";

    public f(String str, String str2, String str3, String str4, String str5) {
        this.a = str;
        this.b = str2;
        this.c = str3;
        this.d = str4;
        this.e = str5;
    }

    public final String a() {
        return a.c(this.a);
    }

    public final void a(String str) {
        this.a = str;
    }

    public final String b() {
        return a.c(this.b);
    }

    public final void b(String str) {
        this.b = str;
    }

    public final String c() {
        return a.c(this.c);
    }

    public final void c(String str) {
        this.c = str;
    }

    public final String d() {
        return a.c(this.d);
    }

    public final void d(String str) {
        this.d = str;
    }

    public final String e() {
        return a.c(this.e);
    }

    public final void e(String str) {
        this.e = str;
    }
}
