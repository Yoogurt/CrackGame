package com.alipay.apmobilesecuritysdk.face;

public class EnvModeConfig {
    public static final int ENVIRONMENT_AAA = 4;
    public static final int ENVIRONMENT_DAILY = 1;
    public static final int ENVIRONMENT_ONLINE = 0;
    public static final int ENVIRONMENT_PRE = 2;
    public static final int ENVIRONMENT_SIT = 3;
}
