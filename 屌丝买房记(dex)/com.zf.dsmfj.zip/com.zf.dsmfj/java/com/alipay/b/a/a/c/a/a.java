package com.alipay.b.a.a.c.a;

public class a {
    public boolean a = false;
    public String b = "";
}
