package com.alipay.b.a.a.c;

import android.content.Context;
import com.alipay.b.a.a.c.b.a;
import com.alipay.b.a.a.c.b.b;

public final class d {
    public static a a(Context context, String str) {
        return context == null ? null : b.a(context, str);
    }
}
