package com.alipay.b.a.a.c.a;

public final class c extends a {
    public String c;
    public String d;
    public String e;
    public String f;
    public String g;
    public String h;
    public String i;
    public String j;
}
