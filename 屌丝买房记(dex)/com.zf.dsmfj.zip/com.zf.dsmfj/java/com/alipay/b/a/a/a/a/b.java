package com.alipay.b.a.a.a.a;

import com.alipay.b.a.a.a.a;
import java.security.MessageDigest;

public final class b {
    public static String a(String str) {
        String str2 = null;
        try {
            if (!a.a(str)) {
                MessageDigest instance = MessageDigest.getInstance("SHA-1");
                instance.update(str.getBytes(com.alipay.sdk.sys.a.m));
                byte[] digest = instance.digest();
                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < digest.length; i++) {
                    stringBuilder.append(String.format("%02x", new Object[]{Byte.valueOf(digest[i])}));
                }
                str2 = stringBuilder.toString();
            }
        } catch (Exception e) {
        }
        return str2;
    }
}
