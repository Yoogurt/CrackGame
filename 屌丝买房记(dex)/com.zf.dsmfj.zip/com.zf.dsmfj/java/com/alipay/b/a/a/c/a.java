package com.alipay.b.a.a.c;

import com.alipay.tscenter.biz.rpc.report.general.model.DataReportRequest;
import com.alipay.tscenter.biz.rpc.report.general.model.DataReportResult;

public interface a {
    DataReportResult a(DataReportRequest dataReportRequest);

    boolean a(String str);
}
