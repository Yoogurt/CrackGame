package com.alipay.b.a.a.c.a;

import com.alipay.b.a.a.a.a;
import java.util.HashMap;
import java.util.Map;

public final class d {
    private String a;
    private String b;
    private String c;
    private String d;
    private String e;
    private Map<String, String> f;
    private String g;
    private String h;
    private String i;

    public final String a() {
        return a.c(this.a);
    }

    public final void a(String str) {
        this.a = str;
    }

    public final void a(Map<String, String> map) {
        this.f = map;
    }

    public final String b() {
        return a.c(this.b);
    }

    public final void b(String str) {
        this.b = str;
    }

    public final String c() {
        return a.c(this.c);
    }

    public final void c(String str) {
        this.c = str;
    }

    public final String d() {
        return a.c(this.d);
    }

    public final void d(String str) {
        this.d = str;
    }

    public final Map<String, String> e() {
        return this.f == null ? new HashMap() : this.f;
    }

    public final void e(String str) {
        this.e = str;
    }

    public final String f() {
        return this.e;
    }

    public final void f(String str) {
        this.g = str;
    }

    public final void g(String str) {
        this.h = str;
    }

    public final void h(String str) {
        this.i = str;
    }
}
