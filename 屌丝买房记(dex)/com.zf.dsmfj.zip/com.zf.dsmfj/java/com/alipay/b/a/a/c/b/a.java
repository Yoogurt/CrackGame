package com.alipay.b.a.a.c.b;

import com.alipay.b.a.a.c.a.c;
import com.alipay.b.a.a.c.a.d;

public interface a {
    c a(d dVar);

    boolean a(String str);
}
