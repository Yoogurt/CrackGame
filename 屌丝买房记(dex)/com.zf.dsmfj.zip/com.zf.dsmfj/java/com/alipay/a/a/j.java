package com.alipay.a.a;

public interface j {
    Object a(Object obj);

    boolean a(Class<?> cls);
}
