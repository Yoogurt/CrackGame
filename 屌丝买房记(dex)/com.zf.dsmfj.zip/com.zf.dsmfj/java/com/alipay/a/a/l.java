package com.alipay.a.a;

import com.alipay.a.b.a;
import java.lang.reflect.Type;

public final class l implements i, j {
    public final Object a(Object obj) {
        return obj;
    }

    public final Object a(Object obj, Type type) {
        return obj;
    }

    public final boolean a(Class<?> cls) {
        return a.a((Class) cls);
    }
}
