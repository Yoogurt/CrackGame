package com.qq.e.comm.managers.status;

public class SDKStatus {
    public static final String getSDKVersion() {
        return "4.9";
    }

    public static final int getSDKVersionCode() {
        return 1;
    }
}
