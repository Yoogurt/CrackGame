package com.qq.e.comm.adevent;

public interface ADListener {
    void onADEvent(ADEvent aDEvent);
}
