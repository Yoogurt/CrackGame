package com.qq.e.comm.managers.plugin;

public final class b extends Exception {
    public b(String str) {
        super(str);
    }

    public b(String str, Throwable th) {
        super(str, th);
    }
}
