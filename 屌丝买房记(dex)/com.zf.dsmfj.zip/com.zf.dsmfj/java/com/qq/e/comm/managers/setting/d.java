package com.qq.e.comm.managers.setting;

public final class d {
    private String a;
    private c b;

    private d(String str, c cVar) {
        this.a = str;
        this.b = cVar;
    }

    public final String a() {
        return this.a;
    }

    public final c b() {
        return this.b;
    }
}
