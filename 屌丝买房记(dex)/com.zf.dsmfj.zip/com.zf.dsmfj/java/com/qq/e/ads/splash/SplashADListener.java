package com.qq.e.ads.splash;

public interface SplashADListener {
    void onADClicked();

    void onADDismissed();

    void onADPresent();

    void onADTick(long j);

    void onNoAD(int i);
}
