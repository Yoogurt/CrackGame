package com.qq.e.ads.appwall;

public interface GridAPPWallListener {
    void onADDismissed();

    void onADPresent();

    void onNoAD(int i);
}
