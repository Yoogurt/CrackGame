package com.qq.e.ads.nativ;

import com.qq.e.comm.adevent.ADEvent;
import com.qq.e.comm.adevent.ADListener;
import com.qq.e.comm.util.GDTLogger;
import com.zf.dsmfj.Constant;

public class MediaListenerAdapter implements ADListener {
    private MediaListener a;

    public MediaListenerAdapter(MediaListener mediaListener) {
        this.a = mediaListener;
    }

    public void onADEvent(ADEvent aDEvent) {
        switch (aDEvent.getType()) {
            case Constant.DIALOG_NEWGAME /*1*/:
                if (aDEvent.getParas().length == 1 && (aDEvent.getParas()[0] instanceof Integer)) {
                    this.a.onVideoReady((long) ((Integer) aDEvent.getParas()[0]).intValue());
                    return;
                } else {
                    GDTLogger.e("NativeMedia ADEvent Paras error!");
                    return;
                }
            case Constant.DIALOG_BUYGOODS /*2*/:
                this.a.onVideoStart();
                return;
            case Constant.DIALOG_SELLGOODS /*3*/:
                this.a.onVideoPause();
                return;
            case Constant.DIALOG_ENDGAME /*4*/:
                this.a.onVideoComplete();
                return;
            case Constant.DIALOG_BANK /*5*/:
                if (aDEvent.getParas().length == 1 && (aDEvent.getParas()[0] instanceof Integer)) {
                    this.a.onVideoError(((Integer) aDEvent.getParas()[0]).intValue());
                    return;
                } else {
                    GDTLogger.e("NativeMedia ADEvent Paras error!");
                    return;
                }
            case Constant.DIALOG_BANK_SAVE /*6*/:
                this.a.onReplayButtonClicked();
                return;
            case Constant.DIALOG_BANK_GET /*7*/:
                this.a.onADButtonClicked();
                return;
            case Constant.DIALOG_HOSPITAL_ASK /*8*/:
                if (aDEvent.getParas().length == 1 && (aDEvent.getParas()[0] instanceof Boolean)) {
                    this.a.onFullScreenChanged(((Boolean) aDEvent.getParas()[0]).booleanValue());
                    return;
                } else {
                    GDTLogger.e("NativeMedia ADEvent Paras error!");
                    return;
                }
            default:
                return;
        }
    }
}
