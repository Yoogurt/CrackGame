package com.qq.e.ads.banner;

public enum ADSize {
    BANNER
}
