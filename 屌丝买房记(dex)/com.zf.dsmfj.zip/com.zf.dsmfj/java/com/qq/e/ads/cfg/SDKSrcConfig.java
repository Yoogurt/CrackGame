package com.qq.e.ads.cfg;

public class SDKSrcConfig {
    private static String a;

    public static String getSdkSrc() {
        return a;
    }

    public static void setSdkSrc(String str) {
        a = str;
    }
}
